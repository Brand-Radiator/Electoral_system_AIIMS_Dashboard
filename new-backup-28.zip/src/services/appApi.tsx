import { createApi, fetchBaseQuery} from '@reduxjs/toolkit/query/react'

// create the api

export const appApi= createApi({
    reducerPath:'appApi',
    baseQuery: fetchBaseQuery({ baseUrl:"http://localhost:5000"}),
    endpoints:(builder)=>({
        signup:builder.mutation({//mutation for changing thiings
            query:(user)=>({ // query takes user
                url:'/signup/upload',//url
                method:'POST',
                body:user,
            }),
        }),

        login:builder.mutation({
            query:(user)=>({
                url:"/login",
                method:"POST",
                body:user,
            }),
        }),
    }),
})

export const {useSignupMutation, useLoginMutation} = appApi

export default appApi;