//  slice managed by our redux tools
import appApi from "../services/appApi"
import {createSlice} from '@reduxjs/toolkit';

// for initialised
const initialState =null;

export const userSlice = createSlice({
    name:'user',
    initialState,
    reducers:{
        logout:()=> initialState,
    },

// extra slicers used to store our data in our state
    extraReducers:(builder) => {// it will match our app api,kind of listen to events
        builder.addMatcher(appApi.endpoints.signup.matchFulfilled,(_,{payload})=> payload);
        builder.addMatcher(appApi.endpoints.login.matchFulfilled,(_,{payload})=> payload);

    }

})
export const {logout} = userSlice.actions

export default userSlice.reducer;