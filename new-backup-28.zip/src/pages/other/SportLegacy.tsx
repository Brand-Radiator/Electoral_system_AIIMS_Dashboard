import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { Row, Col, Card, Button, InputGroup, Form, Table } from "react-bootstrap";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

// components
import PageTitle from "../../components/PageTitle";
import { FormInput, VerticalForm } from "../../components";

interface sportLegecy {
    _id: string;
    aboutText:string;
    bannerUrl: string;
    mobileBannerUrl:string;
}
// interface MyComponentProps {
//     data: sportLegecy[];
//   }


// ------------------------add menu ---------------------------------------------
// const AddSportLegecy: React.FC<MyComponentProps> = ({ sportLegecy }) => {
const AddSportLegecy = () => {
    const [validated, setValidated] = useState<boolean>(false);
    const [missionandvision, setMissionandVision] = useState<sportLegecy[]>([]);

    const [aboutText, setAboutText] = useState("");
    const [bannerUrl, setBannerUrl] = useState<File | null>(null);
    const [mobileBannerUrl, setMobileBannerUrl] = useState<File | null>(null);




    const handleSubmit = async (event: any) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        }

        setValidated(true);
    };


    // useEffect(() => {
    //     fetch('http://localhost:5000/get/missionandvission')
    //         .then(response => response.json())
    //         .then(res => setMissionandVision(res))// resolve this response/ promise
    // }, [])




    //   ------------------------------------------ setting image in the input--------------------------------
    const handleBannerUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setBannerUrl(e.target.files[0]);
        }
    };

    const handleMobileBannerUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setMobileBannerUrl(e.target.files[0]);
        }
    };



// ------------------------------------------ for adding menu -------------------------------------
    const addMenu = async (event: React.FormEvent<HTMLFormElement>) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        } else {
            event.preventDefault();
            const formData = new FormData();
            formData.append("aboutText", aboutText);
            if (bannerUrl) {
                formData.append("bannerUrl", bannerUrl);
            }
            if (mobileBannerUrl) {
                formData.append("mobileBannerUrl", mobileBannerUrl);
            }
            console.log("formData-------,", formData);

            try {
                const response = await fetch(
                    `http://localhost:5000/api/menus`,
                    {
                        method: "POST",
                        body: formData,
                    }
                );
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                // Assuming you want to parse the JSON response
                const data = await response.json();
                console.log("data -----------", data);
            } catch (error) {
                console.error("Error during edit the banner:", error);
            }
        }
        setValidated(true);
    };
// ______________________________________________________________________________________________________________________________________

    // ------------------------------------------ for adding menu -------------------------------------
    const updateMenu = async (event: React.FormEvent<HTMLFormElement>) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        } else {
            event.preventDefault();
            const formData = new FormData();
            formData.append("aboutText", aboutText);
            if (bannerUrl) {
                formData.append("bannerUrl", bannerUrl);
            }
            if (mobileBannerUrl) {
                formData.append("mobileBannerUrl", mobileBannerUrl);
            }
            console.log("formData-------,", formData);

            try {
                const response = await fetch(
                    `http://localhost:5000/api/update/hello/${''}`,
                    {
                        method: "POST",
                        body: formData,
                    }
                );
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                // Assuming you want to parse the JSON response
                const data = await response.json();
                console.log("data -----------", data);
            } catch (error) {
                console.error("Error during edit the banner:", error);
            }
        }
        setValidated(true);
    };
// ______________________________________________________________________________________________________________________________________


    return (
        <>
        {/* {data.length==0 ?( */}
         <Card>
         <Card.Body>
             <Form
                 style={{ width: "100%" }}
                 onSubmit={addMenu}
                 encType="multipart/form-data"
             >
                 <h4>Add Sport Legacy</h4>
                 {/* <> */}
                 <Form.Group>
                     <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                         <h5>Mission Content</h5>
                     </Form.Label>
                     <Form.Control
                         className="accordion-item"
                         type="text"
                         placeholder="Mission Content"
                         defaultValue=""
                         onChange={(e) => setAboutText(e.target.value)}
                     />
                 </Form.Group>

                 <Form.Group>
                     <Form.Label className="d-flex pt-1 justify-content-start">
                         <h5>Banner Image</h5>
                     </Form.Label>
                     <Form.Control
                         type="file"
                         id="image"
                         name="bannerUrl"
                         accept="image/*"
                         onChange={handleBannerUrl}
                     />
                 </Form.Group>

                 <Form.Group>
                     <Form.Label className="d-flex pt-1 justify-content-start">
                         <h5>Mobile Banner</h5>
                     </Form.Label>

                     <Form.Control
                         type="file"
                         id="image"
                         name="mobileBannerUrl"
                         accept="image/*"
                         onChange={handleMobileBannerUrl}
                     />
                 </Form.Group>

                 <Form.Group className="pt-5 pb-5">
                     <Button type="submit">Add</Button>
                 </Form.Group>
             </Form>
         </Card.Body>
     </Card>

        {/* ): */}
{/* ( */}
    <Card>
    <Card.Body>
        <Form
            style={{ width: "100%" }}
            // onSubmit={}
            encType="multipart/form-data"
        >
            <h4>Add Sport Legacy</h4>
            {/* <> */}
            <Form.Group>
                <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                    <h5>Mission Content</h5>
                </Form.Label>
                <Form.Control
                    className="accordion-item"
                    type="text"
                    placeholder="Mission Content"
                    defaultValue=""
                    onChange={(e) => setAboutText(e.target.value)}
                />
            </Form.Group>


            <Form.Group>
                <Form.Label className="d-flex pt-1 justify-content-start">
                    <h5>Banner Image</h5>
                </Form.Label>
                <Form.Control
                    type="file"
                    id="image"
                    name="bannerUrl"
                    accept="image/*"
                    onChange={handleBannerUrl}
                />
            </Form.Group>

            <Form.Group>
                <Form.Label className="d-flex pt-1 justify-content-start">
                    <h5>Mobile Banner</h5>
                </Form.Label>

                <Form.Control
                    type="file"
                    id="image"
                    name="mobileBannerUrl"
                    accept="image/*"
                    onChange={handleMobileBannerUrl}
                />
            </Form.Group>

            <Form.Group className="pt-5 pb-5">
                <Button type="submit">Update</Button>
            </Form.Group>
        </Form>
    </Card.Body>
</Card>
{/* ) */}
        {/* } */}



        </>
    );
};

// ___________________________________________________________________________________________________________________







const FormValidation = () => {
// ------------------------------------------------------ get Sport legecy data
    const [sportLegecyData, setSportLegecyData] = useState<sportLegecy[]>([]);

    useEffect(() => {
        fetch('http://localhost:5000/api/get/hello')
            .then(response => response.json())
            .then(res => setSportLegecyData(res))// resolve this response/ promise
    }, [])

    console.log('sportLegecyData--', sportLegecyData)

    return (
        <React.Fragment>
            <PageTitle
                breadCrumbItems={[
                    // { label: "Forms", path: "/forms/gallery" },
                    // { label: "Validation", path: "/forms/gallery", active: true },

                    { label: "Pages", path: "/pages/sportlegecy" },
                    {
                        label: "Sport Legecy",
                        path: "/pages/sportlegecy",
                        active: true,
                    },
                ]}
                title={"Sport Legecy "}
            />
            {/* <Row>


                {missionandvision.length >= 1 ? (
                    // <Col lg={10}>
                    //     <AddSportLegecy />
                    // </Col>
                    ""
                ) : (
                    <Col lg={10}>
                        <AddSportLegecyItem />
                    </Col>
                )}
            </Row> */}
            <Row>
                {/* <Col lg={12}>
                    <DeleteMissionAndVision />
                </Col> */}

                <Col lg={6}>
                    <AddSportLegecy/>
                </Col>

            </Row>
        </React.Fragment>
    );
};

export default FormValidation;
