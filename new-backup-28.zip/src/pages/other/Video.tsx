import React, { useEffect, useState } from "react";
import { Button, Card, Col, Form, Row, Table } from "react-bootstrap";
import PageTitle from "../../components/PageTitle";

interface missionAndVisionAchievement {
  _id: string;
  bannerUrl: string;
  mobileBannerUrl: string;
  description: string;
  title: string;
  eventName: string;
  videoUrl: string;
}

interface parentId {
  itemId?: string; // Replace 'boolean' with the appropriate type if needed
  id?: string;
  parentId?: string;
  innerdata?: [];
}
interface id {
  id: string;

}
interface ChildComponentProps {
  refreshFlag: number;
}

const DeleteVideo: React.FC<ChildComponentProps> = ({ refreshFlag }) => {
  const [validated, setValidated] = useState<boolean>(false);

  const [missionandvision, setMissionandVision] = useState<missionAndVisionAchievement[]>([]);

  const deleteItem = async (itemId: string) => {
    try {
      const response = await fetch(
        `http://localhost:5000/api/delete/video/${itemId}`,
        {
          method: "PATCH",
        }
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      // Assuming you want to parse the JSON response
      const data = await response.json();
      console.log("data -----------", data);
      const userConfirmed = window.confirm("Deleted");

      if (userConfirmed) {
        window.location.reload();
      }
    } catch (error) {
      console.error("Error during edit the banner:", error);
    }
  };
  useEffect(() => {
    fetch("http://localhost:5000/api/video")
      .then((response) => response.json())
      .then((res) => setMissionandVision(res));
  }, []);

  console.log(missionandvision, "data");

  return (
    <>
      <>
        <h4>Delete Video Page </h4>

        <Card>
          <Card.Body>
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>Sr. N</th>
                  <th>Title</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                {(missionandvision || []).map((item, i) => (
                  <tr key={item._id}>
                    <td>{i + 1}</td> {/* You can use i+1 as the index */}
                    <td>{item?.title}</td>
                    <td>
                      {/* Delete button */}
                      <button
                        onClick={() => deleteItem(item._id)}
                        className="btn btn-danger"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Card.Body>
        </Card>
      </>
    </>
  );
};


const UpdateVideoItem: React.FC<parentId> = ({
  itemId, parentId
}) => {
  const [validated, setValidated] = useState<boolean>(false);
  const [data, setData] = useState<missionAndVisionAchievement[]>([]);
  const [description, setDescription] = useState("");
  const [eventName, setEventName] = useState("");
  const [videoUrl, setVideoUrl] = useState("");

  const [thumbnail, setThumbnail] = useState<File | null>(null);

  // ------------------------- for saving the data to updte

  useEffect(() => {
    fetch(`http://localhost:5000/api/video/${parentId}`)
      .then((response) => response.json())
      .then((res) => setData(res.filteredData)); // resolve this response/ promise
  }, []);

  const handleSubmit = async (event: any) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };

  //   ------------------------------------------ setting image in the input--------------------------------
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setThumbnail(e.target.files[0]);
    }
  };

  const UpdateOrgStruItem = async (
    event: React.FormEvent<HTMLFormElement>
  ) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("eventName", eventName);
      formData.append("videoUrl", videoUrl);
      formData.append("description", description);
      if (thumbnail) formData.append("thumbnail", thumbnail);


      console.log("formData-------,", formData);

      try {
        const response = await fetch(
          `http://localhost:5000/api/update/video/${parentId}/videoItem/${itemId}`,
          {
            method: "PATCH",
            body: formData,
          }
        );
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        const userConfirmed = window.confirm("updated");

        if (userConfirmed) {
          window.location.reload();
        }
       } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };


  const cancleRequest = ()=>{
    const userConfirmed = window.confirm("want to cancle");
    if(userConfirmed) window.location.reload();
  }
  // const cancleRequest =() = >{
    // const userConfirmed = window.confirm("Deleted");

    // if (userConfirmed) {
    //   window.location.reload();
    // }
  // }

  console.log('data from upadate----', data)


  return (
    <>
      <Card>
        <Card.Body>
          {(data || [])
            .filter((item) => {
              // console.log("from the line 248--", item._ === itemId);
              console.log('filter', item._id)
              return item._id === itemId;
            })
            .map((filterItem, index) => (
              <Form
                style={{ width: "100%" }}
                onSubmit={UpdateOrgStruItem}
                encType="multipart/form-data"
              >

                <h4>Update Service</h4>
                {/* <> */}
                <Form.Group>
                  <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                    <h5>Title</h5>
                  </Form.Label>
                  <Form.Control
                    className="accordion-item"
                    type="text"
                    placeholder={filterItem?.eventName}
                    defaultValue={filterItem?.eventName}
                    onChange={(e) => setEventName(e.target.value)}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                    <h5>Video Url</h5>
                  </Form.Label>
                  <Form.Control
                    className="accordion-item"
                    type="text"
                    placeholder={filterItem?.videoUrl}
                    defaultValue={filterItem?.videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                    <h5>Title</h5>
                  </Form.Label>
                  <Form.Control
                    className="accordion-item"
                    type="text"
                    placeholder={filterItem?.description}
                    defaultValue={filterItem?.description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="d-flex pt-1 justify-content-start">
                    <h5>Thumbnail</h5>
                  </Form.Label>
                  <Form.Control
                    type="file"
                    id="image"
                    name="thumbnail"
                    accept="image/*"
                    onChange={handleFileChange}
                  />
                </Form.Group>
                <Row>
                  <Col lg={3}>
                    <Form.Group className="pt-5 pb-5">
                      <Button type="submit">Update</Button>
                    </Form.Group>
                  </Col>

                  <Col lg={3}>
                    <Form.Group className="pt-5 pb-5">
                      <Button type="button" onClick={()=>cancleRequest()}>cancle</Button>
                    </Form.Group>
                  </Col>
                </Row>


              </Form>
            ))}
        </Card.Body>
      </Card>
    </>
  );
};
// _________________________________________________________


// const DeleteOriStruItem = ({id}) => {
const DeleteVideoItem: React.FC<id> = ({ id }) => {
  const [validated, setValidated] = useState<boolean>(false);
  const [innerdata, setInnerData] = useState<missionAndVisionAchievement[]>([]);
  const [isEditItem, setIsEditItem] = useState<string>("");


  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/video/${id}`);
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();

        if (data.length > 0) {
          // Assuming you want to set the pageId to the first item's _id
          // setPageId(data[0]._id);
        }
        setInnerData(data.filteredData);

      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData(); // Call the async function to fetch and set data
  }, []);


  // --delete org str item
  const deleteItem = async (itemId: string) => {
    try {
      console.log("rtgjiyg o-------------", id, "-----", itemId)
      const response = await fetch(
        `http://localhost:5000/api/delete/video/${id}/videoItem/${itemId}`,
        {
          method: "PATCH",
        }
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      // Assuming you want to parse the JSON response
      // const data = await response.json();
      const userConfirmed = window.confirm("Deleted");

      if (userConfirmed) {
        window.location.reload();
      }
      // alert("Deleted")
    } catch (error) {
      console.error("Error during edit the banner:", error);
    }
  };

  const editItem = async (id: string) => {
    console.log("child id----------------", id);
    let newEditItem = innerdata.find((elem) => {
      console.log("child id----------------", id, 'element._id', elem._id);

      return elem._id === id;
    });
    setIsEditItem(id);
  };
  console.log('isEditItem', isEditItem)



  const updateItem = async (itemId: string) => {
    console.log("hello", itemId);
  };


  console.log('innerdata', innerdata, 'id from delete --------', id)

  return (
    // <h1>hi</h1>
    <>
      {isEditItem ? (
        <Row>
          <Col lg={10}>
            <UpdateVideoItem itemId={isEditItem} parentId={id} />
          </Col>
        </Row>
      ) : (
        <>
          <h4>Update or delete videos inside Video Page</h4>

          <Card>
            <Card.Body>
              <Table striped bordered hover>
                <thead>
                  <tr>
                    <th className="w-5px">#</th>
                    <th className="w-60">Video Title</th>
                    <th>Actions</th> {/* New column for actions */}
                  </tr>
                </thead>
                {(innerdata || []).map((item, i) => (
                  <>
                    <tbody>
                      <tr key={item._id}>
                        <td>{i + 1}</td> {/* You can use i+1 as the index */}
                        <td>{item.eventName}</td>
                        <td>
                          {/* Delete button */}
                          <button
                            onClick={() => deleteItem(item._id)}
                            className="btn btn-danger"
                          >
                            Delete
                          </button>

                          <button
                            onClick={() => editItem(item._id)}
                            className="btn btn-primary"
                          >
                            Update
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </>
                ))}
              </Table>
            </Card.Body>
          </Card>
        </>
      )}
    </>
  );
};

// -------------------------------add org item----------------

const AddVideoItem: React.FC<id> = ({ id }) => {
  const [validated, setValidated] = useState<boolean>(false);
  const [description, setDescription] = useState("");
  const [eventName, setEventName] = useState("");
  const [videoUrl, setVideoUrl] = useState("");

  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const handleSubmit = async (event: any) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }
    setValidated(true);
  };

  const addVideoItem = async (event: React.FormEvent<HTMLFormElement>) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("eventName", eventName);
      formData.append("videoUrl", videoUrl);
      formData.append("description", description);
      if (thumbnail) formData.append("thumbnail", thumbnail);
      console.log("formData-------,", formData);
      try {
        const response = await fetch(`http://localhost:5000/api/video/${id}`, {
          method: "POST",
          body: formData,
        });
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        const userConfirmed = window.confirm("Deleted");

        if (userConfirmed) {
          window.location.reload();
        }
      } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setThumbnail(e.target.files[0]);
    }
  };

  return (
    <>
      <Card>
        <Card.Body>
          <Form
            style={{ width: "100%" }}
            onSubmit={addVideoItem}
            encType="multipart/form-data"
          >

            <h4>Add Videos in video page</h4>
            {/* <> */}
            <Form.Group>
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                <h5>Event Name</h5>
              </Form.Label>
              <Form.Control
                className="accordion-item"
                type="text"
                placeholder='Event Name'
                defaultValue=''
                onChange={(e) => setEventName(e.target.value)}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                <h5>Video Url</h5>
              </Form.Label>
              <Form.Control
                className="accordion-item"
                type="text"
                placeholder='videoUrl'
                defaultValue=''
                onChange={(e) => setVideoUrl(e.target.value)}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                <h5>Title</h5>
              </Form.Label>
              <Form.Control
                className="accordion-item"
                type="text"
                placeholder='description'
                defaultValue=''
                onChange={(e) => setDescription(e.target.value)}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label className="d-flex pt-1 justify-content-start">
                <h5>Thumbnail</h5>
              </Form.Label>
              <Form.Control
                type="file"
                id="image"
                name="thumbnail"
                accept="image/*"
                onChange={handleFileChange}
              />
            </Form.Group>

            <Form.Group className="pt-5 pb-5">
              <Button type="submit">Add</Button>
            </Form.Group>
          </Form>
        </Card.Body>
      </Card>
    </>
  );
};


const AddVideo = () => {
  const [validated, setValidated] = useState<boolean>(false);
  const [introductionData, setIntroductionData] = useState<
    missionAndVisionAchievement[]
  >([]);
  const [refreshFlag, setRefreshFlag] = useState<number>(0);

  const [description, setDescription] = useState("");
  const [title, setTitle] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [bannerUrl, setBannerUrl] = useState<File | null>(null);
  const [mobileBannerUrl, setMobileUrl] = useState<File | null>(null);
  const handleSubmit = async (event: any) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }
    setValidated(true);
  };

  useEffect(() => {
    fetch("http://localhost:5000/api/video")
      .then((response) => response.json())
      .then((res) => setIntroductionData(res)); // resolve this response/ promise
  }, []);

  //   ------------------------------------------ setting image in the input--------------------------------
  const handleBannerUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setBannerUrl(e.target.files[0]);
    }
  };

  const handleMobileUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setMobileUrl(e.target.files[0]);
    }
  };

  /*---------------- handle Form submit ---------------------------------------*/

  const handleFormSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("description", description);
      formData.append("title", title);
      formData.append("videoUrl", videoUrl);
      if (bannerUrl) { formData.append("bannerUrl", bannerUrl); }
      if (mobileBannerUrl) { formData.append("mobileBannerUrl", mobileBannerUrl); }
      console.log("formData-------,", formData);

      try {
        const response = await fetch(`http://localhost:5000/api/video`, {
          method: "POST",
          body: formData,
        });
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        const userConfirmed = window.confirm("Deleted");

        if (userConfirmed) {
          window.location.reload();
        }
      } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };

  /*----------------  handle update----------------*/

  let objectId: any;
  if (introductionData.length > 0) {
    const { _id } = introductionData[0];
    objectId = _id;
  }

  const handleUpdate = async (event: React.FormEvent<HTMLFormElement>) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("description", description);
      formData.append("title", title);

      if (bannerUrl) { formData.append("bannerUrl", bannerUrl); }
      if (mobileBannerUrl) { formData.append("mobileBannerUrl", mobileBannerUrl); }


      try {
        const response = await fetch(
          `http://localhost:5000/api/update/video/${objectId}`,
          {
            method: "PATCH",
            body: formData,
          }
        );
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        const userConfirmed = window.confirm("updated");

        if (userConfirmed) {
          window.location.reload();
        }

      } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };
  console.log('title', title)

  console.log('length', introductionData.length)

  console.log('description', description)


  return (
    <>
      <div>
        <PageTitle
          breadCrumbItems={[
            { label: "Pages", path: "/pages/prerna-policy" },
            {
              label: "Video",
              path: "/pages/video",
              active: true,
            },
          ]}
          title={"Video"}
        />
        <Card>
          <Card.Body>
            <Row>
              {introductionData.length === 1 ? (
                <Col lg={6}>
                  <Form
                    style={{ width: "100%" }}
                    onSubmit={handleUpdate}
                    encType="multipart/form-data"
                  >
                    <h4>Update Video Page</h4>
                    {/* <> */}
                    <Form.Group>
                      <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                        <h5>Title</h5>
                      </Form.Label>
                      <Form.Control
                        className="accordion-item"
                        type="text"
                        placeholder="Event Name"
                        defaultValue={introductionData[0]?.title}
                        onChange={(e) => setTitle(e.target.value)}
                      />
                    </Form.Group>

                    <Form.Group>
                      <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                        <h5>Description</h5>
                      </Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="Description"
                        defaultValue={introductionData[0]?.description}
                        onChange={(e) => setDescription(e.target.value)}
                      />
                    </Form.Group>

                    <Form.Group>
                      <Form.Label className="d-flex pt-1 justify-content-start">
                        <h5>Desktop Banner Image</h5>
                      </Form.Label>
                      <Form.Control
                        type="file"
                        id="image"
                        name="bannerUrl"
                        accept="image/*"
                        onChange={handleBannerUrl}
                      />
                    </Form.Group>

                    <Form.Group>
                      <Form.Label className="d-flex pt-1 justify-content-start">
                        <h5>Mobile Banner Image</h5>
                      </Form.Label>
                      <Form.Control
                        type="file"
                        id="image"
                        name="mobileBannerUrl"
                        accept="image/*"
                        onChange={handleMobileUrl}
                      />
                    </Form.Group>

                    <Form.Group className="pt-5 pb-5">
                      <Button type="submit">Update</Button>
                    </Form.Group>
                  </Form>

                </Col>
              ) : (
                <Col lg={6}>
                  <Form
                    style={{ width: "100%" }}
                    onSubmit={handleFormSubmit}
                    encType="multipart/form-data"
                  >
                    <h4>Add Video Page</h4>
                    {/* <> */}
                    <Form.Group>
                      <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                        <h5>Title</h5>
                      </Form.Label>
                      <Form.Control
                        className="accordion-item"
                        type="text"
                        placeholder="Event Name"
                        defaultValue={introductionData[0]?.title}
                        onChange={(e) => setTitle(e.target.value)}
                      />
                    </Form.Group>

                    <Form.Group>
                      <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                        <h5>Description</h5>
                      </Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="Description"
                        defaultValue={introductionData[0]?.description}
                        onChange={(e) => setDescription(e.target.value)}
                      />
                    </Form.Group>

                    <Form.Group>
                      <Form.Label className="d-flex pt-1 justify-content-start">
                        <h5>Desktop Banner Image</h5>
                      </Form.Label>
                      <Form.Control
                        type="file"
                        id="image"
                        name="bannerUrl"
                        accept="image/*"
                        onChange={handleBannerUrl}
                      />
                    </Form.Group>

                    <Form.Group>
                      <Form.Label className="d-flex pt-1 justify-content-start">
                        <h5>Mobile Banner Image</h5>
                      </Form.Label>
                      <Form.Control
                        type="file"
                        id="image"
                        name="mobileBannerUrl"
                        accept="image/*"
                        onChange={handleMobileUrl}
                      />
                    </Form.Group>

                    <Form.Group className="pt-5 pb-5">
                      <Button type="submit">Add</Button>
                    </Form.Group>
                  </Form>
                </Col>
              )}

              {/* -------------------------- update data--------------------------------------------- */}

              <Col lg={6}>
                <DeleteVideo refreshFlag={refreshFlag} />

              </Col>
              {/* for adding and deleting the video from video page */}
            </Row>
            <Row>
              <Col lg={6}>
                <AddVideoItem id={objectId} />
              </Col>
              <Col lg={6}>
                {objectId && <DeleteVideoItem id={objectId} />}

              </Col>
            </Row>

          </Card.Body>
        </Card>

      </div>
    </>
  );
};

export default AddVideo;
