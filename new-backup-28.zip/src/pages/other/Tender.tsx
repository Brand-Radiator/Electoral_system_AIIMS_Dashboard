// src/components/PersonForm.tsx
import React, { useState } from "react";
import axios from "axios";

const PersonForm: React.FC = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    try {
      const data = await axios.post(
        "http://localhost:5000/add/marquees",
        formData
      );
      console.log("Data saved to MongoDB", data);
    } catch (error) {
      console.error("Error saving data:", error);
    }
  };
  console.log("formData", formData);
  return (
    <div>
      <h2>Add a Tender</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="firstName">Start Date:</label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label htmlFor="lastName">End Date:</label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleInputChange}
            required
          />
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default PersonForm;
