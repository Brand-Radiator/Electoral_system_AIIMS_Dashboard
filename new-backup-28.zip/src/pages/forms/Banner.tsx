import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import {
  Row,
  Col,
  Card,
  Button,
  InputGroup,
  Form,
  Table,
} from "react-bootstrap";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

// components
import PageTitle from "../../components/PageTitle";
import { FormInput, VerticalForm } from "../../components";

interface banner {
  _id: string;
  bannerTitle: string;
  description: string;
  mobileBannerUrl: string;
  desktopBannerUrl: string;
}

const NormalFormValidation = () => {
  const [validated, setValidated] = useState<boolean>(false);
  const [bannerData, setBannerData] = useState<banner[]>([]);

  const [bannerTitle, setBannerTitle] = useState("");
  const [description, setDescription] = useState("");
  const [desktopBannerUrl, setDesktopBannerUrl] = useState<File | null>(null);
  const [mobileBannerUrl, setMobileBannerUrl] = useState<File | null>(null);

  const handleSubmit = async (event: any) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };

  useEffect(() => {
    fetch("http://localhost:5000/get/missionandvission")
      .then((response) => response.json())
      .then((res) => setBannerData(res)); // resolve this response/ promise
  }, []);

  //   ------------------------------------------ setting image in the input--------------------------------
  const handleMobileBannerUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setMobileBannerUrl(e.target.files[0]);
    }
  };

  const handleDesktopBannerUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setDesktopBannerUrl(e.target.files[0]);
    }
  };

  const addBanner = async (event: React.FormEvent<HTMLFormElement>) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("bannerTitle", bannerTitle);
      formData.append("description", description);

      if (mobileBannerUrl) {
        formData.append("mobileBannerUrl", mobileBannerUrl);
      }
      if (desktopBannerUrl) {
        formData.append("desktopBannerUrl", desktopBannerUrl);
      }
      console.log("formData-------,", formData);

      try {
        const response = await fetch(`http://localhost:5000/add/banner`, {
          method: "POST",
          body: formData,
        });
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        console.log("data -----------", data);
      } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };

  console.log("missionandvision.length", addBanner.length);
  return (
    <>
      <Card>
        <Card.Body>
          <Form
            style={{ width: "100%" }}
            onSubmit={addBanner}
            encType="multipart/form-data"
          >
            <h4>Add Banner</h4>
            {/* <> */}
            <Form.Group>
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                <h5>Banner Title</h5>
              </Form.Label>
              <Form.Control
                className="accordion-item"
                type="text"
                placeholder="Banner Title"
                defaultValue=""
                onChange={(e) => setBannerTitle(e.target.value)}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                <h5>Description</h5>
              </Form.Label>
              <Form.Control
                type="text"
                placeholder="Description"
                defaultValue=""
                onChange={(e) => setDescription(e.target.value)}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label className="d-flex pt-1 justify-content-start">
                <h5>Banner Image</h5>
              </Form.Label>
              <Form.Control
                type="file"
                id="image"
                name="desktopBannerUrl"
                accept="image/*"
                onChange={handleDesktopBannerUrl}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label className="d-flex pt-1 justify-content-start">
                <h5>Mobile Banner</h5>
              </Form.Label>

              <Form.Control
                type="file"
                id="image"
                name="mobileBannerUrl"
                accept="image/*"
                onChange={handleMobileBannerUrl}
              />
            </Form.Group>

            <Form.Group className="pt-5 pb-5">
              <Button type="submit">Add Banner</Button>
            </Form.Group>
          </Form>
        </Card.Body>
      </Card>
    </>
  );
};

// const UpdateMissionAndVision = () => {
//     const [validated, setValidated] = useState<boolean>(false);
//     const [missionandvision, setMissionandVision] = useState<banner[]>([]);

//     const [playerName, setPlayerName] = useState("");
//     const [achievement, setAchievement] = useState("");
//     const [year, setYear] = useState("");

//     const [missionDescription, setMissionDescription] = useState("");
//     const [VisionDescription, setVisionDescription] = useState("");

//     const [bannerUrl, setBannerUrl] = useState<File | null>(null);
//     const [missionUrl, setMissionUrl] = useState<File | null>(null);
//     const [VisionUrl, setVisionUrl] = useState<File | null>(null);
//     const [mobileBannerUrl, setMobileBannerUrl] = useState<File | null>(null);

//     useEffect(() => {
//         fetch('http://localhost:5000/get/missionandvission')
//             .then(response => response.json())
//             .then(res => setMissionandVision(res))// resolve this response/ promise
//     }, [])

//     const handleSubmit = async (event: any) => {
//         const form = event.currentTarget;
//         if (form.checkValidity() === false) {
//             event.preventDefault();
//             event.stopPropagation();
//         }

//         setValidated(true);
//     };

//     //   ------------------------------------------ setting image in the input--------------------------------
//     const handleBannerUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
//         if (e.target.files && e.target.files.length > 0) {
//             setBannerUrl(e.target.files[0]);
//         }
//     };

//     const handleMissionUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
//         if (e.target.files && e.target.files.length > 0) {
//             setMissionUrl(e.target.files[0]);
//         }
//     };

//     const handleVisionUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
//         if (e.target.files && e.target.files.length > 0) {
//             setVisionUrl(e.target.files[0]);
//         }
//     };

//     console.log("from update", missionandvision[0]?._id)

//     const updateMissionandVision = async (event: React.FormEvent<HTMLFormElement>) => {
//         const form = event.currentTarget;
//         if (form.checkValidity() === false) {
//             event.preventDefault();
//             event.stopPropagation();
//         } else {
//             event.preventDefault();
//             const formData = new FormData();
//             formData.append("missionDescription", missionDescription);
//             formData.append("VisionDescription", VisionDescription);

//             if (bannerUrl) {
//                 formData.append("bannerUrl", bannerUrl);
//             }
//             if (missionUrl) {
//                 formData.append("missionUrl", missionUrl);
//             }
//             if (VisionUrl) {
//                 formData.append("VisionUrl", VisionUrl);
//             }

//             console.log("formData-------,", formData);

//             try {
//                 const response = await fetch(
//                     `http://localhost:5000/update/missionandvission/${missionandvision[0]?._id}`,
//                     {
//                         method: "PATCH",
//                         body: formData,
//                     }
//                 );
//                 if (!response.ok) {
//                     throw new Error(`HTTP error! Status: ${response.status}`);
//                 }
//                 // Assuming you want to parse the JSON response
//                 const data = await response.json();
//                 console.log("data -----------", data);
//             } catch (error) {
//                 console.error("Error during edit the banner:", error);
//             }
//         }
//         setValidated(true);
//     };

//     console.log(missionDescription)

//     return (
//         <>
//             <Card>
//                 <Card.Body>
//                     <Form
//                         style={{ width: "100%" }}
//                         onSubmit={updateMissionandVision}
//                         encType="multipart/form-data"
//                     >
//                         <h4>Update Mission and Vision</h4>
//                         {/* <> */}
//                         <Form.Group>
//                             <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
//                                 <h5>Mission Content</h5>
//                             </Form.Label>
//                             <Form.Control
//                                 className="accordion-item"
//                                 type="text"
//                                 placeholder={missionandvision[0]?.missionDescription}
//                                 defaultValue={missionandvision[0]?.missionDescription}
//                                 onChange={(e) => setMissionDescription(e.target.value)}
//                             />
//                         </Form.Group>

//                         <Form.Group>
//                             <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
//                                 <h5>Vision Content</h5>
//                             </Form.Label>
//                             <Form.Control
//                                 type="text"
//                                 placeholder={missionandvision[0]?.VisionDescription}
//                                 defaultValue={missionandvision[0]?.VisionDescription}
//                                 onChange={(e) => setVisionDescription(e.target.value)}
//                             />
//                         </Form.Group>

//                         <Form.Group>
//                             <Form.Label className="d-flex pt-1 justify-content-start">
//                                 <h5>Banner Image</h5>
//                             </Form.Label>
//                             <Form.Control
//                                 type="file"
//                                 placeholder="fhfhfhfh"
//                                 id="image"
//                                 name="bannerUrl"
//                                 accept="image/*"
//                                 onChange={handleBannerUrl}
//                             />
//                         </Form.Group>

//                         <Form.Group>
//                             <Form.Label className="d-flex pt-1 justify-content-start">
//                                 <h5>Mission Image</h5>
//                             </Form.Label>
//                             <Form.Control
//                                 type="file"
//                                 id="image"
//                                 name="missionUrl"
//                                 accept="image/*"
//                                 onChange={handleMissionUrl}
//                             />
//                         </Form.Group>

//                         <Form.Group>
//                             <Form.Label className="d-flex pt-1 justify-content-start">
//                                 <h5>Vision Image</h5>
//                             </Form.Label>
//                             <Form.Control
//                                 type="file"
//                                 id="image"
//                                 name="VisionUrl"
//                                 accept="image/*"
//                                 onChange={handleVisionUrl}
//                             />
//                         </Form.Group>
//                         <Form.Group className="pt-5 pb-5">
//                             <Button type="submit">Update</Button>
//                         </Form.Group>
//                     </Form>
//                 </Card.Body>
//             </Card>

//         </>
//     );
// };

// ---------------------------------      Delete   ------------------------------
const DeleteBanner = () => {
  const [validated, setValidated] = useState<boolean>(false);

  const [bannerData, setBannerData] = useState<banner[]>([]);

  const deleteItem = async (itemId: string) => {
    try {
      const response = await fetch(
        `http://localhost:5000/delete/banner/${itemId}`,
        {
          method: "PATCH",
        }
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      // Assuming you want to parse the JSON response
      const data = await response.json();
      console.log("data -----------", data);
    } catch (error) {
      console.error("Error during edit the banner:", error);
    }
  };
  useEffect(() => {
    fetch("http://localhost:5000/get/banner")
      .then((response) => response.json())
      .then((res) => setBannerData(res)); // resolve this response/ promise
  }, []);
  console.log("banner  data ", bannerData);

  return (
    <>
      <h4>Delete Mission and vision</h4>

      <Card>
        <Card.Body>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>#</th>
                <th>Notice Title</th>
                <th>Actions</th> {/* New column for actions */}
              </tr>
            </thead>
            {(bannerData || []).map((item, i) => (
              <tbody>
                <tr key={item._id}>
                  <td>{i + 1}</td> {/* You can use i+1 as the index */}
                  <td>{item.bannerTitle}</td>
                  <td>
                    {/* Delete button */}
                    <button
                      onClick={() => deleteItem(item._id)}
                      className="btn btn-danger"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              </tbody>
            ))}
          </Table>
        </Card.Body>
      </Card>
    </>
  );
};

const FormValidation = () => {
  return (
    <React.Fragment>
      <PageTitle
        breadCrumbItems={[
          // { label: "Forms", path: "/forms/gallery" },
          // { label: "Validation", path: "/forms/gallery", active: true },

          { label: "Pages", path: "/pages/banner" },
          {
            label: "Banner ",
            path: "/pages/banner",
            active: true,
          },
        ]}
        title={"Banner Section"}
      />
      <Row>
        {/*
                    <Col lg={6}>
                        <UpdateMissionAndVision />
                    </Col> */}
        <Col lg={6}>
          <NormalFormValidation />
        </Col>
      </Row>
      <Row>
        <Col lg={12}>
          <DeleteBanner />
        </Col>
      </Row>
    </React.Fragment>
  );
};

export default FormValidation;
