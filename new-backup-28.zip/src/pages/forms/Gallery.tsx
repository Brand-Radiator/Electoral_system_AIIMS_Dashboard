import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { Row, Col, Card, Button, InputGroup, Form, Table } from "react-bootstrap";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

// components
import PageTitle from "../../components/PageTitle";
import { FormInput, VerticalForm } from "../../components";
// import Table from "../../components/Table";

interface galleryData3 {
    _id:string;
    title: string;
    paragraph: string;
    eventType: string;
    image: string;
}

const NormalFormValidation = () => {
    const [validated, setValidated] = useState<boolean>(false);

    const [galleryData,setGalleryData] = useState<galleryData3[]>([])
    const [title, setTitle] = useState('')
    const [paragraph, setParagraph] =useState('')
    const [eventType, setEventType] =useState('')
    const [image, setImage] =useState<File | null>(null)

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
          setImage(e.target.files[0]);
        }
      };

    const handleSubmit = (event: any) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        }
        setValidated(true);
    };

    const addGallery = async(event: React.FormEvent<HTMLFormElement>)=>{
        const form = event.currentTarget;
        event.preventDefault();
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        }
        else{
            const formData = new FormData()
            formData.append('title', title);
            formData.append('paragraph', paragraph);
            formData.append('eventType', eventType);
            if (image) {
                formData.append('image', image);
              }

            console.log('formData-------,', formData);
            try {
                const response = await fetch(`http://localhost:5000/add/gallery`, {
                    method: 'POST',
                    body: formData,
                });
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                // Assuming you want to parse the JSON response
                const data = await response.json();
                alert("Image added")
                console.log("data -----------", data)
            } catch (error) {
                console.error('Error during edit the banner:', error);
            }
        }
        setValidated(true);
    }



    return (
        <>
            <Card>
                <Card.Body>
                <Form style={{ width: "100%" }} onSubmit={addGallery}>
                            <h1>Edit gallery</h1>
                                {/* <> */}
                                    <Form.Group>
                                        <Form.Label className='d-flex  pt-2justify-content-start font-weight-bold'><h5>Title</h5></Form.Label>
                                        <Form.Control className="accordion-item" type='text' placeholder='Title' defaultValue='' onChange={(e) => setTitle(e.target.value)} />
                                    </Form.Group>

                                    <Form.Group>
                                        <Form.Label className='d-flex  pt-2justify-content-start font-weight-bold'><h5>Paragraph</h5></Form.Label>
                                        <Form.Control type='text' placeholder='Enter paragraph' defaultValue='' onChange={(e) => setParagraph(e.target.value)} />
                                    </Form.Group>

                                    <Form.Group>
                                        <Form.Label className='d-flex  pt-2justify-content-start font-weight-bold'><h5>Event Type</h5></Form.Label>
                                        <Form.Control className="accordion-item" type='text' placeholder='enter Event Type' defaultValue="" onChange={(e) => setEventType(e.target.value)} />
                                    </Form.Group>

                                    <Form.Group>
                                        <Form.Label className='d-flex pt-1 justify-content-start'><h5>Image</h5></Form.Label>
                                        <Form.Control type="file" id="image" name="image" accept="image/*" onChange={handleFileChange} />
                                    </Form.Group>

                                    <Form.Group className='pt-5 pb-5'>
                                        <Button type='submit'>Add image</Button>
                                    </Form.Group>
                        </Form>
                </Card.Body>
            </Card>
        </>
    );
};


// ----------------------- delete gallery section------------------------
const DeleteGallery = () => {
    const [validated, setValidated] = useState<boolean>(false);
    const [rerender, setRerender] = useState<boolean>(false)
    const [galleryData, setGalleryData] = useState<galleryData3[]>([]);

    const deleteItem = async (itemId: string) => {
        try {
            const response = await fetch(`http://localhost:5000/delete/gallery/${itemId}`, {
                method: 'PATCH',
            });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            // Assuming you want to parse the JSON response
            const data = await response.json();
            alert("Image Deleted")
            console.log("data -----------", data)
        } catch (error) {
            console.error('Error during edit the banner:', error);
        }
    }

    useEffect(() => {
        fetch('http://localhost:5000/get/gallery')
            .then(response => response.json())
            .then(res => setGalleryData(res))// resolve this response/ promise

    }, [rerender])


    console.log('galleryData--------', galleryData)

    return (
        <>
        {galleryData.length>=1?(
            <>
          <h4>Delete Sponsers</h4>

          <Card>
              <Card.Body>

                  <Table striped bordered hover>
                      <thead>
                          <tr>
                              <th>#</th>
                              <th>Notice Title</th>
                              <th>Actions</th> {/* New column for actions */}

                          </tr>
                      </thead>
                      <tbody>
                          {(galleryData || []).map((item, i) => (
                              <tr key={item._id}>
                                  <td>{i + 1}</td> {/* You can use i+1 as the index */}
                                  <td>{item.title}</td>
                                  <td>
                                      {/* Delete button */}
                                      <button
                                          onClick={() => deleteItem(item?._id)}
                                          className="btn btn-danger"
                                      >
                                          Delete
                                      </button>
                                  </td>
                              </tr>

                          ))}
                      </tbody>
                  </Table>

              </Card.Body>
          </Card>
          </>
        ):""

        }

        </>
    );
};

const FormValidation = () => {
    return (
        <React.Fragment >
            <PageTitle
                breadCrumbItems={[
                    { label: "Forms", path: "/forms/gallery" },
                    { label: "Validation", path: "/forms/gallery", active: true },
                ]}
                title={"Edit Gallery Page"}
            />
            <Row>
                <Col lg={10}>
                    <NormalFormValidation />
                </Col>
            </Row>
            <Row>
                <Col lg={10}>
                    <DeleteGallery />
                </Col>
            </Row>
        </React.Fragment>
    );
};

export default FormValidation;
