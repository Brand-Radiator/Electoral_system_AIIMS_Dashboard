import React, { useEffect, useState, FormEvent } from "react";
import { useForm } from "react-hook-form";
import {
    Row,
    Col,
    Card,
    Button,
    InputGroup,
    Form,
    Table,
} from "react-bootstrap";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
// components
import PageTitle from "../../components/PageTitle";
import { FormInput, VerticalForm } from "../../components";

export interface HeaderType {
    _id: string;
    noticeTitle: string;
    documentlnk: string;
    noticeLink: string;
    image: string;
    new: Boolean
}

// ----------------------------------  add marque   ----------------------------

const AddMarque = () => {
    const [validated, setValidated] = useState<boolean>(false);

    const [eventData, setEventData] = useState<HeaderType[]>([]);
    const [noticeTitle, setNoticeTitle] = useState("");
    const [documentlnk, setDocumentlnk] = useState("");
    const [noticeLink, setNoticeLink] = useState("");
    const [image, setImage] = useState<File | null>(null)


    const handleSubmit = async (event: any) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        }

        setValidated(true);
    };

    const addEvents = async (event: React.FormEvent<HTMLFormElement>) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        } else {
            event.preventDefault();
            const formData = new FormData();
            formData.append("noticeTitle", noticeTitle);
            formData.append("documentlnk", documentlnk);
            formData.append("noticeLink", noticeLink);
            if (image) { formData.append('image', image); }

            console.log("formData-------,", formData);
            // const addData: any = await apiService.post("api/event", formData);
            // const addData: any = await apiService.post("api/event", formData);
            try {
                const response = await fetch(`http://localhost:5000/add/marquees`, {
                    method: "POST",
                    body: formData,
                });
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                // Assuming you want to parse the JSON response
                const data = await response.json();
                alert("Marquee added")
            } catch (error) {
                console.error("Error during edit the banner:", error);
            }
        }
        setValidated(true);
    };


    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setImage(e.target.files[0]);
        }
    };


    return (
        <>
            <Card>
                <Card.Body>
                    <Form
                        style={{ width: "100%" }}
                        onSubmit={addEvents}
                        encType="multipart/form-data"
                    >
                        <h4>Add Marquees</h4>
                        {/* <> */}
                        <Form.Group>
                            <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                                <h5>Notice Title</h5>
                            </Form.Label>
                            <Form.Control
                                className="accordion-item"
                                type="text"
                                placeholder="Title"
                                defaultValue=""
                                onChange={(e) => setNoticeTitle(e.target.value)}
                            />
                        </Form.Group>

                        <Form.Group>
                            <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                                <h5>Document Link</h5>
                            </Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Document Link"
                                defaultValue=""
                                onChange={(e) => setDocumentlnk(e.target.value)}
                            />
                        </Form.Group>

                        <Form.Group>
                            <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                                <h5>Notice Link</h5>
                            </Form.Label>
                            <Form.Control
                                className="accordion-item"
                                type="text"
                                placeholder="Notice Link "
                                defaultValue=""
                                onChange={(e) => setNoticeLink(e.target.value)}
                            />
                        </Form.Group>


                        <Form.Group>
                            <Form.Label className='d-flex pt-1 justify-content-start'><h5>Gif</h5></Form.Label>
                            <Form.Control type="file" id="image" name="image" accept="image/*" onChange={handleFileChange} />
                        </Form.Group>


                        <Form.Group className="pt-5 pb-5">
                            <Button type="submit">Add marquees</Button>
                        </Form.Group>
                    </Form>
                </Card.Body>
            </Card>
        </>
    );
};

// ---------------------------------------delete marquees

const DeleteMarquees = () => {
    const [validated, setValidated] = useState<boolean>(false);

    const [marqueesData, setMarqueesData] = useState<HeaderType[]>([]);

    const deleteItem = async (itemId: string) => {
        try {
            const response = await fetch(
                `http://localhost:5000/delete/marquees/${itemId}`,
                {
                    method: "PATCH",
                }
            );
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            // Assuming you want to parse the JSON response
            alert("Marquee deleted")
            const data = await response.json();
        } catch (error) {
            console.error("Error during edit the banner:", error);
        }
    };


    const MarkAsOld = async (itemId: string) => {
        try {
            const response = await fetch(
                `http://localhost:5000/old/marquees/${itemId}`,
                {
                    method: "PATCH",
                }
            );
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            // Assuming you want to parse the JSON response
            alert("Old Marked")
            const data = await response.json();
        } catch (error) {
            console.error("Error during edit the banner:", error);
        }

    }

    useEffect(() => {
        fetch("http://localhost:5000/get/marquees")
            .then((response) => response.json())
            .then((res) => setMarqueesData(res)); // resolve this response/ promise
    }, []);
    //   console.log("marqueesData--------", marqueesData);

    return (
        <>
            <Card>
                <Card.Body>
                    <h4>Delete Marquees</h4>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Notice Title</th>
                                <th>Actions</th> {/* New column for actions */}
                            </tr>
                        </thead>
                        <tbody>
                            {(marqueesData || []).map((item, i) => (
                                <tr key={item._id}>
                                    <td>{i + 1}</td> {/* You can use i+1 as the index */}
                                    <td>{item.noticeTitle}</td>
                                    <td>
                                        {/* Delete button */}
                                        <div className="d-flex">
                                            <button
                                                onClick={() => deleteItem(item._id)}
                                                className="btn btn-danger"
                                            >
                                                Delt
                                            </button>
                                            {console.log("item.new--------", typeof(item.new))}
                                            {item.new == true ? (
                                                <button
                                                    onClick={() => MarkAsOld(item._id)}
                                                    className="btn btn-primary marginLeft-2px"
                                                >
                                                    Old
                                                </button>
                                            ):
                                            ""}



                                        </div>

                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </Card.Body>
            </Card>
        </>
    );
};

const FormValidation = () => {
    return (
        <React.Fragment>
            <PageTitle
                breadCrumbItems={[
                    { label: "Forms", path: "/forms/marquees" },
                    { label: "Validation", path: "/forms/marquees", active: true },
                ]}
                title={"Marquees section"}
            />
            <Row>
                <Col lg={6}>
                    <AddMarque />
                </Col>
                <Col lg={6}>
                    <DeleteMarquees />
                </Col>
            </Row>
        </React.Fragment>
    );
};

export default FormValidation;
