// import { height } from "@mui/system";
import React, { useEffect, useState } from "react";
import { Button, Card, Col, Form, Row, Table } from "react-bootstrap";
import { useSelector, useDispatch } from 'react-redux';
import { RootState, AppDispatch } from '../../redux/store'



interface OrgtnalSruItem {
  _id: string;
  aboutText: string;
  isDeleted: boolean;
}

interface userData {
  name?: string;
  email?: string;
  password?: string;
  role?: string;
  isDeleted?: boolean;
  imageUrl?: string;
}

interface OrgtnalStru {
  _id: string;
  name?: string;
  bannerUrl?: string;
  mobileBannerUrl?: string;
  OrgtnalSruItem: OrgtnalSruItem[]; // An array of OrgtnalSruItem objects
  // OrgtnalSruItem:array;
  isDeleted: boolean;
  email?: string;
  role?: string;
}

interface UpdateServiceSectionProps {
  itemId: string; // Replace 'boolean' with the appropriate type if needed
  parentId: string;
  innerdata: OrgtnalSruItem[];
}
interface parentId {
  itemId?: string; // Replace 'boolean' with the appropriate type if needed
  id?: string;
  parentId?: string;
}
interface id {
  id?: string;
}

const DeleteOriStru = () => {
  const [validated, setValidated] = useState<boolean>(false);

  const [data, setData] = useState<OrgtnalStru[]>([]);

  const deleteItem = async (itemId: string) => {
    try {
      const response = await fetch(
        `http://localhost:5000/api/delete/orgstructure/${itemId}`,
        {
          method: "PATCH",
        }
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      // Assuming you want to parse the JSON response
      const data = await response.json();
      alert("Deleted");
      console.log("data -----------", data);
    } catch (error) {
      console.error("Error during edit the banner:", error);
    }
  };
  useEffect(() => {
    fetch("http://localhost:5000/user")
      .then((response) => response.json())
      .then((res) => setData(res));
  }, []);

  console.log(' data from -- line 78', data)

  return (
    <>
      <>
        <Card>
          <Card.Body>
            <h4>Delete Employee</h4>

            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>Sr. N</th>
                  <th>Title</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                {(data || []).map((item, i) => (
                  <tr key={item._id}>
                    <td>{i + 1}</td> {/* You can use i+1 as the index */}
                    <td>{item.name}</td>
                    <td>
                      {/* Delete button */}
                      <button
                        onClick={() => deleteItem(item._id)}
                        className="btn btn-danger"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Card.Body>
        </Card>
      </>
    </>
  );
};

// -------------------------------------  for organizational Structured Item  ---------------
// ---999999999999999999 for update item
const UpdateEmployee: React.FC<UpdateServiceSectionProps> = ({
  itemId, parentId, innerdata
}) => {
  console.log("from update line 104", itemId, 'parent-----', parentId, "whole data --", innerdata);
  const [validated, setValidated] = useState<boolean>(false);
  const [serviceSection, setServiceSection] = useState<OrgtnalStru[]>([]);
  const [aboutText, setAboutText] = useState("");
  const [description, setDescription] = useState("");
  const [url, setUrl] = useState("");
  const [image, setImage] = useState<File | null>(null);

  // ------------------------- for saving the data to updte

  useEffect(() => {
    fetch("http://localhost:5000/get/service")
      .then((response) => response.json())
      .then((res) => setServiceSection(res)); // resolve this response/ promise
  }, []);

  const handleSubmit = async (event: any) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };

  //   ------------------------------------------ setting image in the input--------------------------------
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImage(e.target.files[0]);
    }
  };

  const UpdateOrgStruItem = async (
    event: React.FormEvent<HTMLFormElement>
  ) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("aboutText", aboutText);
      console.log("formData-------,", formData);

      try {
        const response = await fetch(
          `http://localhost:5000/api/update/orgstructure/${parentId}/orgstructureitem/${itemId}`,
          {
            method: "PATCH",
            body: formData,
          }
        );
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        console.log("data -----------", data);
      } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };



  return (
    <>
      <Card>
        <Card.Body>
          {(innerdata || [])
            .filter((item) => {
              // console.log("from the line 248--", item._ === itemId);
              console.log('filter', item._id)
              return item._id === itemId;
            })
            .map((filterItem, index) => (
              <Form
                style={{ width: "100%" }}
                onSubmit={UpdateOrgStruItem}
                encType="multipart/form-data"
              >

                <h4>Update Service</h4>
                {/* <> */}
                <Form.Group>
                  <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                    <h5>Title</h5>
                  </Form.Label>
                  <Form.Control
                    className="accordion-item"
                    type="text"
                    placeholder={filterItem?.aboutText}
                    defaultValue={filterItem?.aboutText}
                    onChange={(e) => setAboutText(e.target.value)}
                  />
                </Form.Group>

                <Form.Group className="pt-5 pb-5">
                  <Button type="submit">Update</Button>
                </Form.Group>
              </Form>
            ))}
        </Card.Body>
      </Card>
    </>
  );
};
// _________________________________________________________


// const DeleteOriStruItem = ({id}) => {
const DeleteEmployee: React.FC<parentId> = ({ id }) => {
  const [validated, setValidated] = useState<boolean>(false);
  const [innerdata, setInnerData] = useState<OrgtnalSruItem[]>([]);
  const [isEditItem, setIsEditItem] = useState<string>("");
  const [data, setData] = useState<OrgtnalStru[]>([]);


  // --delete org str item
  const deleteItem = async (itemId: string) => {
    try {
      console.log("rtgjiyg o-------------", id, "-----", itemId)
      const response = await fetch(
        // `http://localhost:5000/api/delete/orgstructure/${id}/orgstructureitem/${itemId}`,
        `http://localhost:5000/api/delete/orgstructure/${id}/orgstructureitem/${itemId}`,

        {
          method: "PATCH",
        }
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      // Assuming you want to parse the JSON response
      const data = await response.json();
      alert("Deleted")
    } catch (error) {
      console.error("Error during edit the banner:", error);
    }
  };

  useEffect(() => {
    fetch("http://localhost:5000/user")
      .then((response) => response.json())
      .then((res) => setData(res));
  }, []);


  const editItem = async (id: string) => {
    console.log("child id----------------", id);
    let newEditItem = innerdata.find((elem) => {
      return elem._id === id;
    });
    setIsEditItem(id);
  };
  console.log('isEditItem', isEditItem)


  const updateItem = async (itemId: string) => {
    console.log("hello", itemId);
  };


  return (
    // <h1>hi</h1>
    <>
      {isEditItem ? (
        <Row>
          <Col lg={10}>
            <UpdateEmployee itemId={isEditItem} parentId={id} innerdata={innerdata} />
          </Col>
        </Row>
      ) : (
        <>
          <Card>
            <Card.Body>
              <h4>Update or delete Roles</h4>
              <div className="table-responsive">
                <Table striped bordered hover>
                  <thead>
                    <tr>
                      <th>Sr. N</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Role</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(data || []).map((item, i) => (
                      <tr key={item._id}>
                        <td>{i + 1}</td> {/* You can use i+1 as the index */}
                        <td>{item.name}</td>
                        <td>{item.email}</td>
                        <td>{item.role}</td>

                        <td>
                          {/* Delete button */}
                          <Row>
                            <Col lg={3}>
                              <button
                                onClick={() => deleteItem(item._id)}
                                className="btn btn-danger"
                              >
                                Delete
                              </button>

                            </Col>
                            <Col lg={3}>
                              <button
                                onClick={() => editItem(item._id)}
                                className="btn btn-primary"
                              >
                                Update
                              </button>

                            </Col>

                          </Row>

                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </div>
            </Card.Body>
          </Card>
        </>
      )}
    </>
  );
};

// -------------------------------add org item----------------

// _______________________________________________________________

const Employees = () => {


  const { user, userLoggedIn, loading, error } = useSelector(
    (state: RootState) => ({
      user: state.Auth.user,
      loading: state.Auth.loading,
      error: state.Auth.error,
      userLoggedIn: state.Auth.userLoggedIn,
    })
  );

  console.log('line number---449--', user)
  // const user = useSelector((state)=> state.user)
  const [data, setData] = useState<userData[]>([]);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [image, setImage] = useState<File | null>(null);;
  const [role, setRole] = useState('')
  const [file, setFile] = useState([])


  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    alert('clicked')

    const formData = new FormData(); // append every thing one by one inside this form data
    formData.append('email', email);
    formData.append('name', name);
    formData.append('password', password);
    formData.append('role', role)
    if (image) { formData.append('image', image) }

    try {
      // await axios.post('http://localhost:5000/signup/upload', formData, {
      //   headers: { 'Content-Type': 'multipart/form-data', },
      // });
      const response = await fetch("http://localhost:5000/signup/upload");
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const userConfirmed = window.confirm("Deleted");

      if (userConfirmed) {
        window.location.reload();

      }

    } catch (error) {
      console.error('Error during registration:', error);
    }
  };

  useEffect(() => {
    fetch("http://localhost:5000/user")
      .then((response) => response.json())
      .then((res) => setData(res));
  }, []);

  //   ------------------------------------------ setting image in the input--------------------------------
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImage(e.target.files[0]);
    }
  };



  /*---------------- handle Form submit ---------------------------------------*/

  const handleFormSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("aboutText", aboutText);

      if (bannerUrl) {
        formData.append("bannerUrl", bannerUrl);
      }
      if (mobileBannerUrl) {
        formData.append("mobileBannerUrl", mobileBannerUrl);
      }

      console.log("formData-------,", formData);

      try {
        const response = await fetch(`http://localhost:5000/api/orgstructure`, {
          method: "POST",
          body: formData,
        });
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        alert("Data added");

        console.log("data -----------", data);
      } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };

  /*----------------  handle update----------------*/

  let objectId: any;
  if (data.length > 0) {
    const { _id } = data[0];
    objectId = _id;
  }

  const handleUpdate = async (event: React.FormEvent<HTMLFormElement>) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("aboutText", aboutText);
      if (bannerUrl) {
        formData.append("bannerUrl", bannerUrl);
      }
      if (mobileBannerUrl) {
        formData.append("mobileBannerUrl", mobileBannerUrl);
      }

      try {
        const response = await fetch(
          `http://localhost:5000/api/update/orgstructure/${objectId}`,
          {
            method: "PATCH",
            body: formData,
          }
        );
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        alert("Updated");
      } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };
  console.log("data ", data)

  console.log("objectId ", objectId)

  return (
    <>
      <div>
        <Card>
          <Card.Body>
            <Row>
              <Col lg={6}>
                <Form style={{ width: "100%" }} onSubmit={handleSubmit}>
                  <h1>Create  Role</h1>

                  <Form.Group>
                    <Form.Label className='d-flex  pt-2 justify-content-start font-weight-bold'><h5>Name</h5></Form.Label>
                    <Form.Control type='text' placeholder='Enter Name' value={name} required onChange={(e) => setName(e.target.value)} />
                  </Form.Group>

                  <Form.Group>
                    <Form.Label className='d-flex pt-2 justify-content-start'><h5>Email address</h5></Form.Label>
                    <Form.Control type='email' placeholder='Enter Email' value={email} required onChange={(e) => setEmail(e.target.value)} />
                  </Form.Group>

                  <Form.Group>
                    <Form.Label className='d-flex pt-2 justify-content-start'><h5>Enter Password</h5></Form.Label>
                    <Form.Control type='password' placeholder='Enter password' value={password} required onChange={(e) => setPassword(e.target.value)} />
                  </Form.Group>

                  <Form.Group>
                    <Form.Label className='d-flex pt-2 justify-content-start'><h5>Image</h5></Form.Label>
                    <Form.Control type="file" id="image" name="image" accept="image/*" onChange={handleImageChange} />
                    {/* <Form.Control type='file' placeholder='choose image' name="image" value ={""} required onChange={handleImageChange}/> */}
                  </Form.Group>

                  <Form.Group className='mb-3 mt-2' onChange={(e) => setRole(e.target.value)}>
                    <Form.Select required>
                      <option disabled selected> Select Role </option>
                      {user.role === "Super Admin" ? <option value='Super Admin'>Super Admin</option> : ''}
                      <option value='Editor'>Editor</option>
                      {/* <option value='Administrator'>Administrator</option> */}
                      {/* <option value='Author'>Author</option> */}
                      {/* <option value='Contributor'>Contributor</option> */}
                      {/* <option value='Subscriber'>Subscriber</option> */}
                    </Form.Select>
                  </Form.Group>

                  <Form.Group className='pt-2 pb-2'>
                    <Button type='submit'>Create</Button>
                    {/* <Button type='submit' className='mt-5'><Link style={{textAlign:"right", display:"bold", textDecoder:"none"}} className='text-light' to="/login">Add user</Link></Button> */}

                  </Form.Group>

                </Form>
              </Col>


              {/* -------------------------- update data--------------------------------------------- */}

            </Row>
            <div style={{ width: "100%", height: "1px", backgroundColor: "red" }} ></div>
            <Row>
              <Col lg={12}>
                {objectId && <DeleteEmployee id={objectId} />}
              </Col>

            </Row>



          </Card.Body>
        </Card>
      </div>
    </>
  );
};

export default Employees;
