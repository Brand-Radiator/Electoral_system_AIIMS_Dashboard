declare module "feather-icons-react";
declare module "react-draft-wysiwyg";
declare module "google-maps-react";
