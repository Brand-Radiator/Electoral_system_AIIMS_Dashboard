import React, { useEffect, useState, FormEvent } from "react";
import { useForm } from "react-hook-form";
import { Row, Col, Card, Button, InputGroup, Form } from "react-bootstrap";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

// components
import PageTitle from "../../components/PageTitle";
import { FormInput, VerticalForm } from "../../components";

export interface HeaderType {
  _id: string;
  designation: string;
  profileName: string;
  slogan: string;
  state: string;
  cmImage: string;
  buttonImage: string;
}

// ------------------------------------------add Header -----------------
const AddHeader = () => {
  const [validated, setValidated] = useState<boolean>(false);

  const [headerData, setHeaderData] = useState<HeaderType[]>([]);
  const [designation, setDesignation] = useState<string>("");
  const [profileName, setProfileName] = useState<string>("");
  const [slogan, setSlogan] = useState<string>("");
  const [state, setState] = useState<string>("");
  const [cmImage, setCmImage] = useState<File | null>(null);
  const [buttonImage, setButtonImage] = useState<File | null>(null);

  useEffect(() => {
    fetch("http://localhost:5000/get/header")
      .then((response) => response.json())
      .then((res) => setHeaderData(res)); // resolve this response/ promise
  }, []);

  const handleCmImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCmImage(e.target.files[0]);
    }
  };

  const handleButtonImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setButtonImage(e.target.files[0]);
    }
  };

  const handleSubmit = async (event: any) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault(); // Prevent the default form submission
      await addHeader(); // Call the editBanner function
    }

    setValidated(true);
  };

  const addHeader = async () => {
    // event.preventDefault();
    const formData = new FormData();
    formData.append("designation", designation);
    formData.append("profileName", profileName);
    formData.append("slogan", slogan);
    formData.append("state", state);
    if (cmImage) {
      formData.append("cmImage", cmImage);
    }
    if (buttonImage) {
      formData.append("buttonImage", buttonImage);
    }
    console.log(formData);
    try {
      const response = await fetch(`http://localhost:5000/add/header`, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      // Assuming you want to parse the JSON response
      const data = await response.json();
      setDesignation("");
      setProfileName("");
      setSlogan("");
      setState("");
      // setImage(null);
      // setImages(null);
    } catch (error) {
      console.error("Error during edit the banner:", error);
    }
  };
  //   -------------------- function for edit the header section ---------------------------

  // ----------------------------------------------------------------------------------------
  console.log("header data -------------", headerData.length);
  return (
    <>
      {headerData.length == 0 ? (
        <Card>
          <Card.Body>
            <Form noValidate validated={validated} onSubmit={handleSubmit}>
              <Form.Group className="mb-1" controlId="validationCustom01">
                <Form.Label>Designation</Form.Label>
                <Form.Control
                  required
                  type="text"
                  placeholder="Designation"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                />
                <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              </Form.Group>
              <Form.Group className="mb-1" controlId="validationCustom02">
                <Form.Label>Profile Name</Form.Label>
                <Form.Control
                  required
                  type="text"
                  placeholder="Profile Name"
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                />
                <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              </Form.Group>
              <Form.Group className="mb-1" controlId="validationCustom02">
                <Form.Label>Slogan</Form.Label>
                <Form.Control
                  required
                  type="text"
                  placeholder="Slogan"
                  value={slogan}
                  onChange={(e) => setSlogan(e.target.value)}
                />
                <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              </Form.Group>
              <Form.Group className="mb-1" controlId="validationCustom02">
                <Form.Label>State</Form.Label>
                <Form.Control
                  required
                  type="text"
                  placeholder="State"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                />
                <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              </Form.Group>

              <Form.Group>
                <Form.Label className="d-flex pt-1 justify-content-start">
                  <h5>CM Image</h5>
                </Form.Label>
                <Form.Control
                  type="file"
                  id="image"
                  name="cmImage"
                  accept="image/*"
                  onChange={handleCmImage}
                />
              </Form.Group>

              <Form.Group>
                <Form.Label className="d-flex pt-1 justify-content-start">
                  <h5>Button image</h5>
                </Form.Label>
                <Form.Control
                  type="file"
                  id="image"
                  name="buttonImage"
                  accept="image/*"
                  onChange={handleButtonImage}
                />
              </Form.Group>

              <Form.Group className="pt-2 pb-1">
                <Button type="submit">Add Header</Button>
              </Form.Group>
            </Form>
          </Card.Body>
        </Card>
      ) : (
        ""
      )}
    </>
  );
};

// ---------------------------------------edit header code start
const UpdateHeader = () => {
  const [validated, setValidated] = useState<boolean>(false);

  const [headerData, setHeaderData] = useState<HeaderType[]>([]);
  const [designation, setDesignation] = useState<string>("");
  const [profileName, setProfileName] = useState<string>("");
  const [slogan, setSlogan] = useState<string>("");
  const [state, setState] = useState<string>("");
  const [cmImage, setCmImage] = useState<File | null>(null);
  const [buttonImage, setButtonImage] = useState<File | null>(null);

  useEffect(() => {
    fetch("http://localhost:5000/get/header")
      .then((response) => response.json())
      .then((res) => setHeaderData(res)); // resolve this response/ promise
  }, []);

  // const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  //     if (e.target.files && e.target.files.length > 0) {
  //       setImage(e.target.files[0]);
  //     }
  //   };

  const handleImage1Change = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCmImage(e.target.files[0]);
    }
  };

  const handleImage2Change = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setButtonImage(e.target.files[0]);
    }
  };

  const handleSubmit = async (event: any) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault(); // Prevent the default form submission
      await editHeader(); // Call the editBanner function
    }

    setValidated(true);
  };

  const editHeader = async () => {
    // event.preventDefault();
    const formData = new FormData();
    formData.append("designation", designation);
    formData.append("profileName", profileName);
    formData.append("slogan", slogan);
    formData.append("state", state);
    if (cmImage) {
      formData.append("cmImage", cmImage);
    }
    if (buttonImage) {
      formData.append("buttonImage", buttonImage);
    }
    console.log(formData);
    try {
      const response = await fetch(
        `http://localhost:5000/update/header/${headerData[0]?._id}`,
        {
          method: "PATCH",
          body: formData,
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      // Assuming you want to parse the JSON response
      const data = await response.json();
      setDesignation("");
      setProfileName("");
      setSlogan("");
      setState("");
    } catch (error) {
      console.error("Error during edit the banner:", error);
    }
  };

  return (
    <>
      <Card>
        <Card.Body>
          <Form noValidate validated={validated} onSubmit={editHeader}>
            {(headerData || []).map((item, i) => (
              <>
                <Form.Group className="mb-1" controlId="validationCustom01">
                  <Form.Label>Designation</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder={item.designation}
                    value={designation}
                    onChange={(e) => setDesignation(e.target.value)}
                  />
                  <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                </Form.Group>
                <Form.Group className="mb-1" controlId="validationCustom02">
                  <Form.Label>Profile Name</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder={item.profileName}
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                  />
                  <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                </Form.Group>
                <Form.Group className="mb-1" controlId="validationCustom02">
                  <Form.Label>Slogan</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder={item.slogan}
                    value={slogan}
                    onChange={(e) => setSlogan(e.target.value)}
                  />
                  <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                </Form.Group>
                <Form.Group className="mb-1" controlId="validationCustom02">
                  <Form.Label>State</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder={item.state}
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                  />
                  <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                </Form.Group>

                <Form.Group>
                  <Form.Label className="d-flex pt-1 justify-content-start">
                    <h5>CM Image</h5>
                  </Form.Label>
                  <Form.Control
                    type="file"
                    id="image"
                    name="cmImage"
                    accept="image/*"
                    onChange={handleImage1Change}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="d-flex pt-1 justify-content-start">
                    <h5>Button image</h5>
                  </Form.Label>
                  <Form.Control
                    type="file"
                    id="image"
                    name="buttonImage"
                    accept="image/*"
                    onChange={handleImage2Change}
                  />
                </Form.Group>

                <Form.Group className="pt-2 pb-1">
                  <Button type="submit">Edit Header</Button>
                </Form.Group>
              </>
            ))}
          </Form>
        </Card.Body>
      </Card>
    </>
  );
};
// ----------------------------------------- edit header code ends----------------------------------

const FormValidation = () => {
  return (
    <React.Fragment>
      <PageTitle
        breadCrumbItems={[
          { label: "Home", path: "/home/header" },
          { label: "Header", path: "/home/header", active: true },
        ]}
        title={"Edit Header section"}
      />

      <Row>
        <Col lg={6}>
          <UpdateHeader />
        </Col>

        <Col lg={6}>
          <AddHeader />
        </Col>
      </Row>
    </React.Fragment>
  );
};

export default FormValidation;
