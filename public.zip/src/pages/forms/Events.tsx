import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { Row, Col, Card, Button, InputGroup, Form, Table } from "react-bootstrap";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import apiService from "../../apiservices/apiService";



// components
import PageTitle from "../../components/PageTitle";
import { FormInput, VerticalForm } from "../../components";

interface eventData {
    _id:string;
    title: string;
    description: string;
    Eventdate: string;
    image: string;
}

const AddEvents = () => {
    const [validated, setValidated] = useState<boolean>(false);

    const [eventData,setEventData] = useState<eventData[]>([])
    const [title, setTitle] = useState('')
    const [description, setDescription] =useState('')
    const [Eventdate, setEventdate] =useState('')
    const [image, setImage] =useState<File | null>(null)


    const handleSubmit = async (event: any) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        }

        setValidated(true);
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
          setImage(e.target.files[0]);
        }
      };



    const addEvents = async(event: React.FormEvent<HTMLFormElement>)=>{
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        }
        else{
            event.preventDefault();
            const formData = new FormData()
            formData.append('title', title);
            formData.append('description', description);
            formData.append('Eventdate', Eventdate);

            if (image) { formData.append('image', image); }
            console.log('formData-------,', formData);
            // const addData: any = await apiService.post("api/event", formData);
            // const addData: any = await apiService.post("api/event", formData);

            try {
                const response = await fetch(`http://localhost:5000/api/Event`, {
                    method: 'POST',
                    body: formData,
                });
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                // Assuming you want to parse the JSON response
                const data = await response.json();
                console.log("data -----------", data)
            } catch (error) {
                console.error('Error during edit the banner:', error);
            }
        }
        setValidated(true);
    }
    console.log(title)
    return (
        <>
            <Card>
                <Card.Body>
                <Form style={{ width: "100%" }} onSubmit={addEvents} encType="multipart/form-data">
                            <h1>Add Events</h1>
                                {/* <> */}
                                    <Form.Group>
                                        <Form.Label className='d-flex  pt-2justify-content-start font-weight-bold'><h5>Title</h5></Form.Label>
                                        <Form.Control className="accordion-item" type='text' placeholder="Title" defaultValue='' onChange={(e) => setTitle(e.target.value)} />
                                    </Form.Group>

                                    <Form.Group>
                                        <Form.Label className='d-flex  pt-2justify-content-start font-weight-bold'><h5>Description</h5></Form.Label>
                                        <Form.Control type='text' placeholder="Description" defaultValue='' onChange={(e) => setDescription(e.target.value)} />
                                    </Form.Group>

                                    <Form.Group>
                                        <Form.Label className='d-flex  pt-2justify-content-start font-weight-bold'><h5>Event Data</h5></Form.Label>
                                        <Form.Control className="accordion-item" type='text' placeholder='Event Date' defaultValue="" onChange={(e) => setEventdate(e.target.value)} />
                                    </Form.Group>

                                    <Form.Group>
                                        <Form.Label className='d-flex pt-1 justify-content-start'><h5>Image</h5></Form.Label>
                                        <Form.Control type="file" id="image" name="image" accept="image/*"  onChange={handleFileChange}/>
                                    </Form.Group>

                                    <Form.Group className='pt-5 pb-5'>
                                        <Button type='submit'>Add Events</Button>
                                    </Form.Group>
                        </Form>
                </Card.Body>
            </Card>
        </>
    );
};



const DeleteEvent = () => {
    const [validated, setValidated] = useState<boolean>(false);

    const [eventData, setEventData] = useState<eventData[]>([]);

    const deleteItem = async (itemId: string) => {
        try {
            const response = await fetch(`http://localhost:5000/delete/event/${itemId}`, {
                method: 'PATCH',
            });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            // Assuming you want to parse the JSON response
            const data = await response.json();
            console.log("data -----------", data)
        } catch (error) {
            console.error('Error during edit the banner:', error);
        }
    }

    useEffect(() => {
        fetch('http://localhost:5000/get/event')
            .then(response => response.json())
            .then(res => setEventData(res))// resolve this response/ promise
    }, [])
    console.log('eventData--------', eventData)

    return (
        <>
            <h4>Delete Marquees</h4>

            <Card>
                <Card.Body>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Actions</th> {/* New column for actions */}

                            </tr>
                        </thead>
                        <tbody>
                            {(eventData || []).map((item, i) => (
                                <tr key={item._id}>
                                    <td>{i + 1}</td> {/* You can use i+1 as the index */}
                                    <td>{item.title}</td>
                                    <td>
                                        {/* Delete button */}
                                        <button
                                            onClick={() => deleteItem(item._id)}
                                            className="btn btn-danger"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </Card.Body>
            </Card>
        </>
    );
};




const FormValidation = () => {
    return (
        <React.Fragment >
            <PageTitle
                breadCrumbItems={[
                    { label: "Forms", path: "/forms/gallery" },
                    { label: "Validation", path: "/forms/gallery", active: true },
                ]}
                title={"Event Section"}
            />
            <Row>
                <Col lg={10}>
                    <AddEvents />
                </Col>
            </Row>
            <Row>
                <Col lg={10}>
                    <DeleteEvent />
                </Col>
            </Row>
        </React.Fragment>
    );
};

export default FormValidation;
