import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import {
  Row,
  Col,
  Card,
  Button,
  InputGroup,
  Form,
  Table,
} from "react-bootstrap";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

// components
import PageTitle from "../../components/PageTitle";
import { FormInput, VerticalForm } from "../../components";

interface newsValidator {
  _id: string;
  title: string;
  description: string;
  image: string;
  postUrl: string;
}

// ------------------------news add section-------------------------------

const NewsCreateCard = () => {
  const [validated, setValidated] = useState<boolean>(false);

  const [galleryData, setGalleryData] = useState<newsValidator[]>([]);
  const [title, setNewsTitle] = useState("");
  const [description, setDescription] = useState("");
  const [postUrl, setPostUrl] = useState("");
  const [image, setImage] = useState<File | null>(null);

  const handleSubmit = async (event: any) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImage(e.target.files[0]);
    }
  };

  const handleAddNews = async (event: React.FormEvent<HTMLFormElement>) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("title", title);
      formData.append("description", description);
      formData.append("postUrl", postUrl);
      if (image) {
        formData.append("image", image);
      }

      try {
        const response = await fetch(`http://localhost:5000/api/news`, {
          method: "POST",
          body: formData,
        });
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        if (data) {
          alert("News added successfully.");
          setNewsTitle("");
          setDescription("");
          setPostUrl("");
          setImage(null);
        }
      } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };

  return (
    <>
      <Card>
        <Card.Body>
          <Form
            style={{ width: "100%" }}
            onSubmit={handleAddNews}
            encType="multipart/form-data"
          >
            <h4 className="header-title">Add News </h4>
            {/* <> */}
            <Form.Group
              className="position-relative mb-3"
              controlId="validationTooltip01"
            >
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                News Title
              </Form.Label>
              <Form.Control
                className="accordion-item"
                type="text"
                placeholder="title"
                defaultValue=""
                onChange={(e) => setNewsTitle(e.target.value)}
              />
            </Form.Group>

            <Form.Group
              className="position-relative mb-3"
              controlId="validationTooltip02"
            >
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                News description
              </Form.Label>
              <Form.Control
                type="text"
                placeholder="News description"
                defaultValue=""
                onChange={(e) => setDescription(e.target.value)}
              />
            </Form.Group>

            <Form.Group
              className="position-relative mb-3"
              controlId="validationTooltip03"
            >
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                News refrence link
              </Form.Label>
              <Form.Control
                type="text"
                placeholder="https://www.google.com"
                defaultValue=""
                onChange={(e) => setPostUrl(e.target.value)}
              />
            </Form.Group>

            <Form.Group
              className="position-relative"
              controlId="validationTooltip04"
            >
              <Form.Label className="d-flex pt-1 justify-content-start">
                News image
              </Form.Label>
              <Form.Control
                type="file"
                id="image"
                name="image"
                accept="image/*"
                onChange={handleFileChange}
              />
            </Form.Group>

            <Form.Group className="pt-5 pb-3">
              <Button type="submit">Add News</Button>
            </Form.Group>
          </Form>
        </Card.Body>
      </Card>
    </>
  );
};

// ---------------------------------      Delete   ------------------------------
const DeleteNews = () => {
  const [validated, setValidated] = useState<boolean>(false);

  const [newsData, setNewsData] = useState<newsValidator[]>([]);

  const deleteItem = async (itemId: string) => {
    try {
      const response = await fetch(`http://localhost:5000/api/news/${itemId}`, {
        method: "PATCH",
      });
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      // Assuming you want to parse the JSON response
      const data = await response.json();
      if (data) {
        alert("News deleted successfully.");
      }
    } catch (error) {
      console.error("Error during edit the banner:", error);
    }
  };

  useEffect(() => {
    fetch("http://localhost:5000/api/news")
      .then((response) => response.json())
      .then((res) => setNewsData(res.newData)); // resolve this response/ promise
  }, []);

  return (
    <>
      <Card>
        <Card.Body>
          <h4 className="header-title">Delete News </h4>
          <Table striped bordered hover width="100">
            <thead>
              <tr>
                <th>SN</th>
                <th>News Title</th>
                <th>Actions</th> {/* New column for actions */}
              </tr>
            </thead>
            <tbody>
              {newsData &&
                newsData?.map((item, i) => (
                  <tr key={item._id}>
                    <td>{i + 1}</td> {/* You can use i+1 as the index */}
                    <td>{item.title}</td>
                    <td>
                      {/* Delete button */}
                      <button
                        onClick={() => deleteItem(item._id)}
                        className="btn btn-danger"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </Table>
        </Card.Body>
      </Card>
    </>
  );
};

const News = () => {
  return (
    <React.Fragment>
      <PageTitle
        breadCrumbItems={[
          { label: "Home", path: "/form/news" },
          {
            label: "News",
            path: "/form/news",
            active: true,
          },
        ]}
        title={"News"}
      />
      <Row>
        <Col lg={6}>
          <NewsCreateCard />
        </Col>
        <Col lg={6}>
          <DeleteNews />
        </Col>
      </Row>
    </React.Fragment>
  );
};

export default News;
