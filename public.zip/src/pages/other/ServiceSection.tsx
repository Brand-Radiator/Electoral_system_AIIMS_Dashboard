import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import {
  Row,
  Col,
  Card,
  Button,
  InputGroup,
  Form,
  Table,
} from "react-bootstrap";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

// components
import PageTitle from "../../components/PageTitle";
import { FormInput, VerticalForm } from "../../components";

interface serviceSection {
  _id: string;
  title: string;
  description: string;
  image: string;
  url: string;
}

interface UpdateServiceSectionProps {
  isEditItem: string; // Replace 'boolean' with the appropriate type if needed
}

const NormalFormValidation = () => {
  const [validated, setValidated] = useState<boolean>(false);
  const [serviceSection, setServiceSection] = useState<serviceSection[]>([]);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [url, setUrl] = useState("");
  const [image, setImage] = useState<File | null>(null);

  const handleSubmit = async (event: any) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }
    setValidated(true);
  };

  useEffect(() => {
    fetch("http://localhost:5000/get/service")
      .then((response) => response.json())
      .then((res) => setServiceSection(res)); // resolve this response/ promise
  }, []);
  //   ------------------------------------------ setting image in the input--------------------------------
  const handleImageUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImage(e.target.files[0]);
    }
  };
  const addGallery = async (event: React.FormEvent<HTMLFormElement>) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("title", title);
      formData.append("description", description);
      formData.append("url", url);
      if (image) {
        formData.append("image", image);
      }

      console.log("formData-------,", formData);
      try {
        const response = await fetch(`http://localhost:5000/add/service`, {
          method: "POST",
          body: formData,
        });
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        console.log("data -----------", data);
      } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };

  console.log("serviceSection.length", serviceSection.length);
  console.log("serviceSection", serviceSection);
  return (
    <>
      <Card>
        <Card.Body>
          <Form
            style={{ width: "100%" }}
            onSubmit={addGallery}
            encType="multipart/form-data"
          >
            <h4>Add Service</h4>
            {/* <> */}
            <Form.Group>
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                <h5>Title</h5>
              </Form.Label>
              <Form.Control
                className="accordion-item"
                type="text"
                placeholder="Title"
                defaultValue=""
                onChange={(e) => setTitle(e.target.value)}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                <h5>Description</h5>
              </Form.Label>
              <Form.Control
                type="text"
                placeholder="Description"
                defaultValue=""
                onChange={(e) => setDescription(e.target.value)}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                <h5>Url</h5>
              </Form.Label>
              <Form.Control
                type="text"
                placeholder="Description"
                defaultValue=""
                onChange={(e) => setUrl(e.target.value)}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label className="d-flex pt-1 justify-content-start">
                <h5>Image</h5>
              </Form.Label>
              <Form.Control
                type="file"
                id="image"
                name="image"
                accept="image/*"
                onChange={handleImageUrl}
              />
            </Form.Group>

            <Form.Group className="pt-5 pb-5">
              <Button type="submit">Add</Button>
            </Form.Group>
          </Form>
        </Card.Body>
      </Card>
    </>
  );
};

// ---------------------------------------- update the item-------------------
const UpdateServiceSection: React.FC<UpdateServiceSectionProps> = ({
  isEditItem,
}) => {
  console.log("from update line 166", isEditItem);
  const [validated, setValidated] = useState<boolean>(false);
  const [serviceSection, setServiceSection] = useState<serviceSection[]>([]);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [url, setUrl] = useState("");
  const [image, setImage] = useState<File | null>(null);

  // ------------------------- for saving the data to updte

  useEffect(() => {
    fetch("http://localhost:5000/get/service")
      .then((response) => response.json())
      .then((res) => setServiceSection(res)); // resolve this response/ promise
  }, []);

  const handleSubmit = async (event: any) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };

  //   ------------------------------------------ setting image in the input--------------------------------
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImage(e.target.files[0]);
    }
  };

  const updateMissionandVision = async (
    event: React.FormEvent<HTMLFormElement>
  ) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    } else {
      event.preventDefault();
      const formData = new FormData();
      formData.append("title", title);
      formData.append("description", description);
      formData.append("url", url);
      if (image) {
        formData.append("image", image);
      }
      console.log("formData-------,", formData);
      try {
        const response = await fetch(
          `http://localhost:5000/update/service/${isEditItem}`,
          {
            method: "PATCH",
            body: formData,
          }
        );
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        // Assuming you want to parse the JSON response
        const data = await response.json();
        console.log("data -----------", data);
      } catch (error) {
        console.error("Error during edit the banner:", error);
      }
    }
    setValidated(true);
  };
  console.log("serviceSection------- line 241", serviceSection);
  return (
    <>
      <Card>
        <Card.Body>
          {(serviceSection || [])
            .filter((item) => {
              console.log("from the line 248--", item._id === isEditItem);
              return item._id === isEditItem;
            })
            .map((filterItem, index) => (
              <Form
                style={{ width: "100%" }}
                onSubmit={updateMissionandVision}
                encType="multipart/form-data"
              >
                <h4>Update Service</h4>
                {/* <> */}
                <Form.Group>
                  <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                    <h5>Title</h5>
                  </Form.Label>
                  <Form.Control
                    className="accordion-item"
                    type="text"
                    placeholder={filterItem?.title}
                    defaultValue={filterItem?.title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                    <h5>Description</h5>
                  </Form.Label>
                  <Form.Control
                    type="text"
                    placeholder={filterItem?.description}
                    defaultValue={filterItem?.description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="d-flex  pt-2justify-content-start font-weight-bold">
                    <h5>url</h5>
                  </Form.Label>
                  <Form.Control
                    type="text"
                    placeholder={filterItem?.url}
                    defaultValue={filterItem?.url}
                    onChange={(e) => setUrl(e.target.value)}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="d-flex pt-1 justify-content-start">
                    <h5>Image</h5>
                  </Form.Label>
                  <Form.Control
                    type="file"
                    id="image"
                    name="image"
                    accept="image/*"
                    onChange={handleFileChange}
                  />
                </Form.Group>

                <Form.Group className="pt-5 pb-5">
                  <Button type="submit">Update</Button>
                </Form.Group>
              </Form>
            ))}
        </Card.Body>
      </Card>
    </>
  );
};

// ---------------------------------      Delete   ------------------------------
const DeleteServiceSection = () => {
  const [validated, setValidated] = useState<boolean>(false);

  const [serviceSection, setServiceSection] = useState<serviceSection[]>([]);
  const [isEditItem, setEditItem] = useState<string>("");

  const deleteItem = async (itemId: string) => {
    try {
      const response = await fetch(
        `http://localhost:5000/delete/service/${itemId}`,
        {
          method: "PATCH",
        }
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      // Assuming you want to parse the JSON response
      const data = await response.json();
      console.log("data -----------", data);
    } catch (error) {
      console.error("Error during edit the banner:", error);
    }
  };

  const editItem = async (id: string) => {
    let newEditItem = serviceSection.find((elem) => {
      return elem._id === id;
    });
    setEditItem(id);
  };

  const updateItem = async (itemId: string) => {
    console.log("hello", itemId);
  };

  useEffect(() => {
    fetch("http://localhost:5000/get/service")
      .then((response) => response.json())
      .then((res) => setServiceSection(res)); // resolve this response/ promise
  }, []);

  return (
    <>
      {isEditItem ? (
        <Row>
          <Col lg={10}>
            <UpdateServiceSection isEditItem={isEditItem} />
          </Col>
        </Row>
      ) : (
        <>
          <h4>Update or delete Service</h4>

          <Card>
            <Card.Body>
              <Table striped bordered hover>
                <thead>
                  <tr>
                    <th className="w-5px">#</th>
                    <th className="w-60">Notice Title</th>
                    <th>Actions</th> {/* New column for actions */}
                  </tr>
                </thead>
                {(serviceSection || []).map((item, i) => (
                  <>
                    <tbody>
                      <tr key={item._id}>
                        <td>{i + 1}</td> {/* You can use i+1 as the index */}
                        <td>{item.title}</td>
                        <td>
                          {/* Delete button */}
                          <button
                            onClick={() => deleteItem(item._id)}
                            className="btn btn-danger"
                          >
                            Delete
                          </button>

                          <button
                            onClick={() => editItem(item._id)}
                            className="btn btn-primary"
                          >
                            Update
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </>
                ))}
              </Table>
            </Card.Body>
          </Card>
        </>
      )}
    </>
  );
};

const FormValidation = () => {
  const [serviceSection, setServiceSection] = useState<serviceSection[]>([]);

  useEffect(() => {
    fetch("http://localhost:5000/get/service")
      .then((response) => response.json())
      .then((res) => setServiceSection(res)); // resolve this response/ promise
  }, []);

  return (
    <React.Fragment>
      <PageTitle
        breadCrumbItems={[
          // { label: "Forms", path: "/forms/gallery" },
          // { label: "Validation", path: "/forms/gallery", active: true },

          { label: "Pages", path: "/pages/service" },
          {
            label: "Service section",
            path: "/pages/service",
            active: true,
          },
        ]}
        title={"Service Section"}
      />
      <Row>
        <Col lg={12}>
          <DeleteServiceSection />
        </Col>
      </Row>
      <Row>
        <Col lg={8}>
          <NormalFormValidation />
        </Col>
      </Row>
    </React.Fragment>
  );
};

export default FormValidation;
